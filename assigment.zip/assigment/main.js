//Question 1
var fruits = ["apple", "banana", "mango", "orange"];
console.log(fruits);
// //Question 2
// let numbers:number[] = [10 ,20 ,30 ,40]
// //Question 3
// let thirdFruit = fruits[2]
// // console.log(thirdFruit);
// // Question 4
// numbers[1] = 25
// console.log(numbers);
// //Question 5
// fruits.push("grapes")
// // console.log(fruits);
// //Question 6
// fruits.pop()
// let lastFruit = fruits
// // console.log(lastFruit);
// //Question 7
// // fruits.shift()
// // let firstFruit = fruits
// // console.log(firstFruit);
// //Question 8
// // fruits.unshift("kiwi")
// // console.log(fruits);
// //Question 9
// fruits.splice(1 ,2)
// console.log(fruits);
// //Question 10
// fruits.splice(2 , 0 , "pineapple" , "pear")
// console.log(fruits);
//Question 11
// let citrusFruits:string[] = fruits.slice(0 ,2)
// console.log(citrusFruits);
// Question 12
var lastTwoFruits = fruits.slice(2, 4);
console.log(lastTwoFruits);
